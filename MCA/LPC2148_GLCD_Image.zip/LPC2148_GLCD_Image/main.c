/*
 * Interfacing LPC2148 with 128x64 Graphic LCD (KS0108) - Display an Image
 *
 * GLCD pin      LPC2148 pin
 * ---------     -----------
 * DB0 - DB7  -> P1.16 - P1.23   (data bus)
 * RS  (D/I)  -> P0.4
 * RW         -> P0.5
 * EN  (E)    -> P0.6
 * CS1        -> P0.7            (left half,  columns 0-63)
 * CS2        -> P0.8            (right half, columns 64-127)
 * RST        -> P0.9
 * VSS -> GND, VDD -> +5V, V0 -> centre of 10k pot (contrast),
 * LED+ -> +5V via resistor, LED- -> GND (backlight)
 *
 * P0.2 / P0.3 / P0.11 / P0.14 are open-drain I2C pins, so they are not used.
 *
 * If your image shows swapped halves  -> swap the CS1 / CS2 wires (or defines).
 * If the screen stays blank           -> set CS_ACTIVE_HIGH to 0.
 *
 * Image data comes from image.h (made with img2glcd.py).
 */

#include <LPC214x.H>
#include "image.h"

/* ---------------- pin map ---------------- */
#define DATA_SHIFT   16
#define DATA_MASK    (0xFFu << DATA_SHIFT)      /* P1.16 - P1.23 */

#define RS           (1u << 4)                  /* P0.4 */
#define RW           (1u << 5)                  /* P0.5 */
#define EN           (1u << 6)                  /* P0.6 */
#define CS1          (1u << 7)                  /* P0.7 */
#define CS2          (1u << 8)                  /* P0.8 */
#define RST          (1u << 9)                  /* P0.9 */
#define CTRL_MASK    (RS | RW | EN | CS1 | CS2 | RST)

#define CS_ACTIVE_HIGH  1                       /* most 20-pin KS0108 modules */

#define LEFT         0
#define RIGHT        1
#define BOTH         2

/* ---------------- delays ---------------- */
/* Tuned for 60 MHz CCLK; simply runs slower (still correct) at 12 MHz. */
static void delay_us(unsigned int us)
{
    volatile unsigned int i;
    while (us--)
        for (i = 0; i < 15; i++);
}

static void delay_ms(unsigned int ms)
{
    while (ms--)
        delay_us(1000);
}

/* ---------------- low level GLCD ---------------- */
static void glcd_select(unsigned char chip)
{
    unsigned int cs = 0;

    if (chip == LEFT  || chip == BOTH) cs |= CS1;
    if (chip == RIGHT || chip == BOTH) cs |= CS2;

#if CS_ACTIVE_HIGH
    IOCLR0 = CS1 | CS2;
    IOSET0 = cs;
#else
    IOSET0 = CS1 | CS2;
    IOCLR0 = cs;
#endif
}

/* write one byte to the selected chip(s): rs = 0 command, rs = 1 data */
static void glcd_write(unsigned char rs, unsigned char val)
{
    if (rs) IOSET0 = RS; else IOCLR0 = RS;
    IOCLR0 = RW;                                /* write mode */

    IOCLR1 = DATA_MASK;
    IOSET1 = ((unsigned int)val << DATA_SHIFT);
    delay_us(1);

    IOSET0 = EN;                                /* EN pulse, data latched on falling edge */
    delay_us(2);
    IOCLR0 = EN;
    delay_us(2);
}

static void glcd_cmd(unsigned char chip, unsigned char cmd)
{
    glcd_select(chip);
    glcd_write(0, cmd);
}

/* ---------------- GLCD functions ---------------- */
void glcd_init(void)
{
    PINSEL0 &= ~0x000FFF00;                     /* P0.4 - P0.9   as GPIO            */
    PINSEL2 &= ~0x00000008;                     /* P1.16 - P1.25 as GPIO (no trace) */

    IODIR0 |= CTRL_MASK;                        /* control lines  = outputs */
    IODIR1 |= DATA_MASK;                        /* data bus       = outputs */

    IOCLR0 = RW | EN;
    IOSET0 = RST;

    IOCLR0 = RST;                               /* hardware reset pulse */
    delay_ms(10);
    IOSET0 = RST;
    delay_ms(10);

    glcd_cmd(BOTH, 0x3F);                       /* display ON      */
    glcd_cmd(BOTH, 0xC0);                       /* start line = 0  */
}

void glcd_clear(void)
{
    unsigned char page, col;

    for (page = 0; page < 8; page++)
    {
        glcd_cmd(BOTH, 0xB8 | page);            /* set page   */
        glcd_cmd(BOTH, 0x40);                   /* set column */
        glcd_select(BOTH);
        for (col = 0; col < 64; col++)
            glcd_write(1, 0x00);
    }
}

/* img = 1024 bytes, page by page, 128 bytes per page, bit0 = top pixel */
void glcd_show_image(const unsigned char *img)
{
    unsigned char page, col;

    for (page = 0; page < 8; page++)
    {
        glcd_cmd(BOTH, 0xB8 | page);            /* set page   */
        glcd_cmd(BOTH, 0x40);                   /* set column */

        glcd_select(LEFT);                      /* columns 0 - 63   */
        for (col = 0; col < 64; col++)
            glcd_write(1, img[page * 128 + col]);

        glcd_select(RIGHT);                     /* columns 64 - 127 */
        for (col = 0; col < 64; col++)
            glcd_write(1, img[page * 128 + 64 + col]);
    }
}

/* ---------------- main ---------------- */
int main(void)
{
    glcd_init();
    glcd_clear();
    glcd_show_image(image);

    while (1);
}
