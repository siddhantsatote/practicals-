LPC2148 + 128x64 GLCD (KS0108) - Display Image
===============================================

Files
  main.c        GLCD driver + main program
  image.h       image data (1024 bytes) - currently the sample picture
  img2glcd.py   converts any picture into image.h
  sample.png    the sample picture used for image.h

Keil uVision steps
  1. Project > New uVision Project > choose NXP > LPC2148.
  2. Click YES when asked to copy the LPC214x startup code.
  3. Add main.c to Source Group 1 (keep image.h in the same folder).
  4. Target options > Output > tick "Create HEX File".
  5. Build, then flash the .hex with Flash Magic (or run in Proteus).

Wiring
  DB0-DB7 -> P1.16-P1.23      CS1 -> P0.7 (left half)
  RS      -> P0.4             CS2 -> P0.8 (right half)
  RW      -> P0.5             RST -> P0.9
  EN      -> P0.6
  VSS -> GND, VDD -> +5V, V0 -> 10k pot centre, backlight A -> +5V (resistor), K -> GND

Use your own image
  pip install pillow
  python img2glcd.py myphoto.png image.h            (add --invert if colours are swapped)
  python img2glcd.py myphoto.png image.h --dither   (better for photos)
  Then rebuild in Keil.

Troubleshooting
  Blank screen         -> set CS_ACTIVE_HIGH to 0 in main.c, check contrast pot (V0)
  Left/right swapped   -> swap CS1 and CS2 wires
  Image inverted       -> run img2glcd.py with --invert
