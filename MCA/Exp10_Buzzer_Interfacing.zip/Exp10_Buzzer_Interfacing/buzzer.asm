; ==============================================================================
; Experiment 10: Buzzer Interfacing (8051 Assembly)
; Buzzer on P2.0 (via NPN transistor), 12 MHz crystal
; ==============================================================================

ORG 0000H

    CLR P2.0            ; Buzzer OFF at start

MAIN:
    SETB P2.0           ; Buzzer ON
    ACALL DELAY         ; ~500 ms beep
    CLR P2.0            ; Buzzer OFF
    ACALL DELAY         ; ~500 ms gap
    SJMP MAIN

; ~500 ms delay @ 12 MHz
DELAY:
    MOV R1, #5
D0: MOV R2, #200
D1: MOV R3, #250
D2: DJNZ R3, D2
    DJNZ R2, D1
    DJNZ R1, D0
    RET

END
