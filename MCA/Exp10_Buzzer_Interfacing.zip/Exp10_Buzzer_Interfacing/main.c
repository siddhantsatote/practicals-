/*
 * Experiment 10: Interfacing Buzzer to 8051
 * Buzzer connected to Port 2.0 (P2.0) through a BC547 NPN transistor
 * (P2.0 -> 1k ohm -> transistor base, buzzer between +5V and collector)
 * Demonstrates: Software delay and ON/OFF beep generation
 * Crystal: 12 MHz
 */

#include <reg51.h>

sbit BUZZER = P2^0;

void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 120; j++);
}

void main(void) {
    BUZZER = 0;          // Buzzer OFF at start

    while (1) {
        BUZZER = 1;      // Buzzer ON
        delay_ms(500);   // 500 ms beep

        BUZZER = 0;      // Buzzer OFF
        delay_ms(500);   // 500 ms gap
    }
}
